---
title: IETF works
date: 2012-09-01
---

The IETF accepts the Trans Working Group charter and begins work on the CT related RFCs.
