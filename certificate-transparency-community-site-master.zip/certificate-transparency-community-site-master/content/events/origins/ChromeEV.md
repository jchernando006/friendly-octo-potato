---
title: Chrome EV
date: 2015-05-01
---

Chrome announces that all EV certificates issued after January 1, 2015 will be required to be CT logged.
