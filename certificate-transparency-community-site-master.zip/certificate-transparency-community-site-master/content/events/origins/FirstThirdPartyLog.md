---
title: First third party log
date: 2013-09-01
---

DigiCert launches the first non-Google CT log to support the growth of the CT ecosystem.
