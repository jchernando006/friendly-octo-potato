---
title: IETF RFC
date: 2013-06-01
isHeadline: true
---

The IETF publishes Certificate Transparency as RFC 6962.
