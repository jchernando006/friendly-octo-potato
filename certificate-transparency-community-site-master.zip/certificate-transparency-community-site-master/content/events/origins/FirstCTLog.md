---
title: First CT Log
date: 2013-03-01
isHeadline: true
---

Google launches their CT logs pre-populated with the certificates discovered by their web crawler.
