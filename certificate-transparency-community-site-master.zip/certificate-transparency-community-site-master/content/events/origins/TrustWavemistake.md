---
title: TrustWave issues root certificate to a customer
date: 2012-02-01
---

U.S. Certificate Authority TrustWave provided subordinate root certificates to a customer which could have been be used to create SSL certificates for nearly any domain on the Internet. CA missteps could lead to severe consequences.
