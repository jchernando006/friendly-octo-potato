---
title: DigiNotar Hack
date: 2011-07-01
isHeadline: true
---

An unknown attacker compromises DigiNotar, a Dutch CA, and issues rogue certificates for numerous domains. Over 500 fake certificates are detected. These certificates were used for man-in-the-middle attacks on traffic from Iran.
