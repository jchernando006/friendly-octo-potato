---
title: Certinomis misissuance
date: 2019-05-01
---

French CA is found to have misissued numerous certificates and is distrusted.