---
title: Apple enforces CT
isHeadline: true
date: 2018-10-01
---

All TLS certificates issued after October 15, 2018 must meet Apple's Certificate Transparency (CT) policy in order to be trusted on Apple platforms.
