---
title: WoSign backdates certificates
date: 2017-07-01
---

CT shows that Chinese CA WoSign/Startcom has backdated certificates, and would later be distrusted.
