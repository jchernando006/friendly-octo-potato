---
title: Symantec misissuance detected
isHeadline: true
date: 2017-09-01
---

CT shows that US CA Symantec has misissued thousands of certificates. Ultimately all major platforms will distrust Symantec.