---
title: Facebook polices certificates internally
date: 2016-04-01
isHeadline: true
---

Facebook announces that [CT helped it detect an internal policy violation](https://www.facebook.com/notes/protect-the-graph/early-impacts-of-certificate-transparency/1709731569266987) and advocates for CT being required not only for EV certificates, but for all certificates issued by CAs.
