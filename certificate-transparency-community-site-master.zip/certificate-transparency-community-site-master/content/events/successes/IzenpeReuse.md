---
title: Izenpe reuses production keys
date: 2016-05-01
---

It is discovered that Izenpe, a Spanish CA and log operator reused their production CT log signing key for test/development purposes, and had inadvertently produced a split view of their log. As a result they are ultimately disqualified as a log operator.
