---
title: CloudFlare Merkle Town
date: 2018-03-01
isHeadline: true
---

CloudFlare launches their [Nimbus CT log](https://blog.cloudflare.com/introducing-certificate-transparency-and-nimbus/) and [Merkle Town](http://merkle.town/), a site making it easy to monitor the CT ecosystems growth.
