---
title: CloudFlare CT monitor
date: 2019-08-01
---

CloudFlare launches a [CT Log monitoring service](https://blog.cloudflare.com/introducing-certificate-transparency-monitoring/) to help customers detect mississued certificates for their domains.
