---
title: Microsoft AD
date: 2018-04-01
isHeadline: true
---

Microsoft [announces support for Certificate Transparency](https://support.microsoft.com/en-us/help/4093260/introduction-of-ad-cs-certificate-transparency) in Active Directory Certificate Services.
