---
title: DigiCert CT monitor
date: 2019-12-01
---

DigiCert launches a [CT Log monitoring service](https://www.digicert.com/news/digicert-launches-ct-log-monitoring-now-available-in-secure-site-pro/) to help customers detect mississued certificates for their domains.
