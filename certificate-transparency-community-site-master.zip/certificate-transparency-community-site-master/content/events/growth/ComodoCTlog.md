---
title: Comodo CT log
date: 2017-03-01
---

COMODO, a UK based CA, announces its contribution of a CT log to support the CT ecosystem.
