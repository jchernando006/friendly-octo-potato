---
title: Let's Encrypt CT monitor
date: 2019-05-01
---

[Let's Encrypt launch Oak](https://sectigo.com/blog/sectigo-is-sponsoring-a-certificate-transparency-ct-log-from-lets-encrypt-heres-why), a free and open Certificate Transparency Log.
