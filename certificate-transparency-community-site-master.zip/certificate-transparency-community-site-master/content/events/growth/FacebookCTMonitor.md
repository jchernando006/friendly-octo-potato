---
title: Facebook CT monitor
date: 2016-12-01
---

Facebook announces their [Certificate Transparency Monitoring Tool](https://www.facebook.com/notes/protect-the-graph/introducing-our-certificate-transparency-monitoring-tool/1811919779048165/) that allows website owners to monitor issues of certificates for domains they own.
