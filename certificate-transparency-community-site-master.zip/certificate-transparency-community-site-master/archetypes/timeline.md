---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
isNegative: false
displayMonth: true
---
